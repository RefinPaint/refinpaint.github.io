# refinpaint.github.io

>companion page featuring examples of submitted paper MUSIC PROOFREADING WITH REFINPAINT: WHERE AND HOW TO MODIFY COMPOSITIONS GIVEN CONTEXT 

## Running Locally

### Prerequisites

- Python 3 installed on your machine.



### Steps

1. Clone or download this repository to your local machine.

2. Open a terminal/command prompt and navigate to the project's directory.

3. Run the following command to start a local HTTP server:



```bash

python -m http.server